import React from "react";

function ManageProduct() {
  return <div>ManageProduct</div>;
}

export default ManageProduct;
