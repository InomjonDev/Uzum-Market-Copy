import React, { useEffect, useState } from "react";
import { db } from "../../../server";
import { collection, getDocs } from "firebase/firestore";

function ManageProduct() {
  return (
    <div>
      <h2>Manage Product</h2>
    </div>
  );
}

export default ManageProduct;
